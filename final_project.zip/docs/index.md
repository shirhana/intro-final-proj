# Welcome to CompressFly Project Documentation

This project aims to develop a Python tool that allows users to compress and decompress files and folders. Users can choose from three types of compression algorithms: Run-Length Encoding (RLE), Huffman coding, and Lempel-Ziv.


## *Easy & Pythonic!!* 


![](https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExYzJ3YmVlMWRxejUzeWZ5ZmttbG5wNXhrYW13OXZwd3ZvcXVtZGtlZSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/cNfdCiR00n8kCKeuhJ/giphy.gif)
