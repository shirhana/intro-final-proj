# Architecture

![ARCHITECTURE](images/architecture.jpg)
